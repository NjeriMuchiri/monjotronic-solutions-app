import React from 'react';
import MainFooter from '../components/mainfooter';
 import MainContainer from '../components/maincontainer';

const Home = () =>{
    return(
    <>
         <div>
          <MainContainer/>
        </div> 
       <div>
         <MainFooter/>
       </div>
        </>
    );
};

export default Home;